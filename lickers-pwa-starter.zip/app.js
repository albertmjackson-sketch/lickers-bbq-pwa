// Basic PWA starter logic
let deferredPrompt;
const installBtn = document.getElementById('installBtn');

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  if (installBtn) installBtn.hidden = false;
});

if (installBtn) {
  installBtn.addEventListener('click', async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    installBtn.hidden = true;
  });
}

// Footer year
document.getElementById('year').textContent = new Date().getFullYear();

// Fake feedback (stores locally). Swap with real backend later.
const form = document.getElementById('feedbackForm');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = {
      name: form.name.value,
      message: form.message.value,
      ts: new Date().toISOString()
    };
    const list = JSON.parse(localStorage.getItem('feedback') || '[]');
    list.push(data);
    localStorage.setItem('feedback', JSON.stringify(list));
    document.getElementById('formStatus').textContent = 'Thanks for your feedback! (Saved on this device)';
    form.reset();
  });
}

// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js');
  });
}
