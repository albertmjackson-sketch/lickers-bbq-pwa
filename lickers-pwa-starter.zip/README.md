# Lickers BBQ — PWA Starter

A minimal, installable Progressive Web App for a restaurant.

## Quick start
1) **Upload these files** to any static host (Netlify, GitHub Pages, Cloudflare Pages, Vercel, or your cPanel host).
2) Make sure the site is served from the project root (so `/service-worker.js` is at the site root).
3) Visit on your phone. After a moment you'll see **Add to Home Screen** (Android) or use **Share → Add to Home Screen** (iOS).

## Edit your info
- Hours/address: `index.html`
- Menu & specials: `index.html`
- Colors & styles: `styles.css`
- Order links: section `#order` in `index.html`
- Icons/logo: replace files in `/assets` (keep the same names/sizes).

## Dev notes
- Service worker caches core assets for offline.
- Update `CACHE_NAME` in `service-worker.js` to force-refresh after changes.
- Lighthouse score: should be 95–100 out of the box.

## Optional extras
- Add analytics (e.g., Plausible, GA4).
- Hook the feedback form to a serverless endpoint (Netlify Forms, Cloudflare Workers, Supabase).
